// Put your Discord application's Client ID here.
const CLIENT_ID = "YOUR_DISCORD_CLIENT_ID";

// These permissions allow the bot to use basic server features.
// Change them if your bot needs different permissions.
const PERMISSIONS = "2147485696";

// Discord OAuth2 invite URL
const inviteUrl =
  `https://discord.com/oauth2/authorize?client_id=${CLIENT_ID}` +
  `&permissions=${PERMISSIONS}&scope=bot%20applications.commands`;

document.getElementById("inviteButton").href = inviteUrl;
document.getElementById("inviteButton2").href = inviteUrl;
